package college;

public class College {
	
	String c_name="Chitkara University";
	String c_address = "Chandigarh-Patiala National Highway (NH- 64),Rajpura";
	
	void get_college() {
		System.out.println("College Name :"+this.c_name);
		System.out.println("College Address :"+this.c_address);
	}
}
