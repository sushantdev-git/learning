package college;

public class Main {
	
	public static void main(String args[]) {
//		B1 Sushant = new B1();
//		Sushant.student_details();
		
		M1 Rahul = new M1();
		Rahul.student_details();
	}
}
