package oops;

class S_class extends F_class
{
    public static void main(final String[] args) {
        final S_class s = new S_class();
        s.get_me();
    }
}
