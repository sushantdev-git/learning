package oops;


public class F_class
{
    void get_me() {
        System.out.println("Ehhhhh");
    }
}