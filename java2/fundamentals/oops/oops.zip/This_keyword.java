package oops;

public class This_keyword {
	
	/*
	 This keyword refer to the current object in a 
	 method or constructor.
	 	
	 */
	public static void main(String args[]) {
		
		construct  c = new construct(5);
		System.out.println(c);
	}
	
	
}
