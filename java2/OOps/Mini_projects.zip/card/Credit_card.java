package card;

public interface Credit_card {
	
	void payRupees();
	void payDollars();
	void payPounds();
	void getBalance();
}
