package bank;

public class Saving extends Account{
	
	void deposit(int n) {
		super.deposit(n);
	}
	
	void withdraw(int n) {
		super.withdraw(n);
	}
}
