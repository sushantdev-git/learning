package bank;

public class Current extends Account{
	
	void deposit(int n) {
		super.deposit(n);
	}
	
	void withdraw(int n) {
		super.withdraw(n);
	}
}
