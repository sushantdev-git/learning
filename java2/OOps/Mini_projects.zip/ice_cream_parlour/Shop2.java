package ice_cream_parlour;

public class Shop2 extends Company{
	
	void Buy() {
		super.Buy(flavour,price,T_flavour);
	}
	
	void addFlavour() {
		super.addFlavour();
	}
	
}
