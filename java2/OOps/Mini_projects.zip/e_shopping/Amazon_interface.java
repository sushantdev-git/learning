package e_shopping;

public interface Amazon_interface {
	//this is amazon interface that user can use to see and buy goods
	void showGoods();
	void BuyGoods();
}
