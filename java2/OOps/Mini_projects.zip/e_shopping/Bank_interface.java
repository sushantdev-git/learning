package e_shopping;

public interface Bank_interface {
	//this is bank_interface that can be used by amazon to process user payment
	boolean Withdraw(double amt);
}


